---
title: 鳥取
url: /prefectures/tottori/
---

## 鳥取の小選挙区

- [鳥取1区](./1/)
- [鳥取2区](./2/)
