---
title: 山形
url: /prefectures/yamagata/
---

## 山形の小選挙区

- [山形1区](./1/)
- [山形2区](./2/)
- [山形3区](./3/)