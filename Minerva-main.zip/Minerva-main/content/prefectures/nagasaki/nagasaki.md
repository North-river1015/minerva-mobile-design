---
title: 長崎
url: /prefectures/nagasaki/
---

## 長崎の小選挙区

- [長崎1区](./1/)
- [長崎2区](./2/)
- [長崎3区](./3/)

