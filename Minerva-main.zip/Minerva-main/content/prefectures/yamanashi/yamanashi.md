---
title: 山梨
url: /prefectures/yamanashi/
---

## 山梨の小選挙区

- [山梨1区](./1/)
- [山梨2区](./2/)
