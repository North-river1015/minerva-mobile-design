---
title: 徳島
url: /prefectures/tokushima/
---

## 徳島の小選挙区

- [徳島1区](./1/)
- [徳島2区](./2/)