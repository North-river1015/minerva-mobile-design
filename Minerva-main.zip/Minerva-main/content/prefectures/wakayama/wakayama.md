---
title: 和歌山
url: /prefectures/wakayama/
---

## 和歌山の小選挙区

- [和歌山1区](./1/)
- [和歌山2区](./2/)
