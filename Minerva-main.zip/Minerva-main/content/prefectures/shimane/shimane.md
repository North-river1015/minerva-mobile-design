---
title: 島根
url: /prefectures/shimane/
---

## 島根の小選挙区

- [島根1区](./1/)
- [島根2区](./2/)